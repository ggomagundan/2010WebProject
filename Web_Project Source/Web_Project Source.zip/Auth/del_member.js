function del(){
      
     var answer = confirm ("정말로 삭제 하시겠습니까?");
   
      if(answer)
            return 1;
      else
            return 0;
       
}
