<div id="footer">
            <div id="page_info">
                  <p>
                        <a href="../PechaKucha/pechakucha.php">pecha kucha?</a> 
                        <a href="../Presentation/presentation.php">presentation</a>
                        <a href="../Board/board.php">board</a>
                        <a href="../Events/events.php">Events</a>
                        <a href="../Sitemap/sitemap.php">SiteMap</a>
                  </p>
                  <p>페차쿠차를 소개하고 참여하는 페이지 입니다.</p>
                  <p>Copyright ⓒ 2010 MJU Webprogramming project team 8.  All rights reserved.</p>
            </div>
      
      <img src="../images/logo_footer2.png" alt="logo" />
                  
</div>   