<div id="navigation">         
      <ul>
            <li><a href="../PechaKucha/pechakucha.php">pecha kucha?</a>
                  <div>
                            <ul>
				  <li><a href="../PechaKucha/pechakucha.php">pecha kucha?</a></li>
				 
                                  <li><a href="../PechaKucha/Android.php">AndroidApp</a></li>
                                  <li><a href="http://www.pecha-kucha.org" target="_blank">페차쿠차홈</a></li>
                                  
                            </ul>
                      </div>
            
            </li>
            <li><a href="../Presentation/presentation.php">presentation</a>
                   <div>
                            <ul>
                                  <li><a href="../Presentation/presentation.php">표지자랑</a></li>                                
                                  <li><a href="../Presentation/atPecha.php">페차쿠차꺼보기</a></li>
                            </ul>
                      </div>
            </li>
            <li><a href="../Board_notice/board.php">board</a>
                   <div>
                            <ul>
										<li><a href="../Board_notice/board.php">공지사항</a></li>
										<li><a href="../Board_free/board.php">자유게시판</a></li>
										<li><a href="../Presentation_share/board.php">PPT 공유</a></li>
										<li><a href="../Board_QA/board.php">Q&#38;A</a></li>
										
                            </ul>
                      </div>
            </li>
            <li><a href="./Events/events.php">events</a>
                   <div>
                            <ul>
                                
                                  <li><li><a href="../Events/events.php">페차쿠차이벤트</a></li></li>
                                  
                            </ul>
                      </div>
            </li>
      </ul>
</div>
                  
